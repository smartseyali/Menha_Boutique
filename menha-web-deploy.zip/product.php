
<?php
$pageTitle = 'Product Details';
include __DIR__ . '/includes/functions.php';
include __DIR__ . '/includes/header.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
$product = [];

if ($id) {
    try {
        $res = callApi('/products/' . $id);
        $product = isset($res['product']) ? $res['product'] : (isset($res) ? $res : []);
    } catch (Exception $e) {
        // Silent failure
    }
}

// Fallback if product still empty
if (empty($product) || !is_array($product)) {
    echo '<div class="container section">Product not found</div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

// Safe Getters
$id = isset($product['id']) ? $product['id'] : (isset($product['_id']) ? $product['_id'] : '');
$name = isset($product['name']) ? $product['name'] : 'Product';
$description = isset($product['description']) ? $product['description'] : '';
$image = getProductImage($product);
$price = getProductPrice($product);
$oldPrice = isset($product['oldPrice']) ? $product['oldPrice'] : null;
$categoryName = isset($product['category']['name']) ? $product['category']['name'] : 'Category';
?>

<div class="product-detail-page section">
    <div class="container">
        <div class="product-layout">
            <div class="product-gallery" style="background:white; border-radius:12px; overflow:hidden;">
                <img src="<?php echo $image; ?>" alt="<?php echo $name; ?>" class="main-image">
            </div>
            
            <div class="product-info-column" style="padding: 1rem;">
                <span class="product-category" style="color:var(--color-primary); font-weight:600; text-transform:uppercase; letter-spacing:1px; font-size:0.9rem;"><?php echo $categoryName; ?></span>
                <h1 class="product-title-lg" style="margin-top:0.5rem;"><?php echo $name; ?></h1>
                
                <div class="product-price-box" style="margin: 1.5rem 0;">
                    <span class="current-price">₹<?php echo $price; ?></span>
                    <?php if ($oldPrice): ?>
                        <span class="old-price" style="text-decoration: line-through; color: #999; margin-left: 10px; font-size: 1.2rem;">₹<?php echo $oldPrice; ?></span>
                    <?php endif; ?>
                </div>

                <div class="product-description" style="color:var(--color-text-light); margin-bottom: 2rem;">
                    <?php echo nl2br($description); ?>
                </div>
                
                <!-- Quantity & Actions -->
                <div class="action-buttons">
                    <div style="display:flex; gap:10px; align-items:center; border:2px solid #eee; border-radius:50px; padding:5px 15px;">
                        <button onclick="changeQty(-1)" style="border:none;background:none;font-size:1.2rem; cursor:pointer;">-</button>
                        <span id="qty-val" style="min-width:20px;text-align:center; font-weight:bold;">1</span>
                        <button onclick="changeQty(1)" style="border:none;background:none;font-size:1.2rem; cursor:pointer;">+</button>
                    </div>
                    <button class="btn btn-outline" onclick="addToCart('<?php echo $id; ?>', parseInt(document.getElementById('qty-val').innerText))" style="border-radius:50px;">
                        <i data-lucide="shopping-bag"></i> Add to Cart
                    </button>
                    <button class="btn btn-primary" onclick="buyNow('<?php echo $id; ?>')" style="border-radius:50px;">
                        Buy Now
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function changeQty(delta) {
        const el = document.getElementById('qty-val');
        let val = parseInt(el.innerText) + delta;
        if (val < 1) val = 1;
        el.innerText = val;
    }
    
    function buyNow(id) {
        addToCart(id, parseInt(document.getElementById('qty-val').innerText));
        window.location.href = 'cart.php';
    }
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
